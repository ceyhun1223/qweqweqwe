const {
  MessageButton,
  MessageEmbed,
  MessageSelectMenu,
  MessageActionRow,
  Permissions,
} = require("discord.js");
const { developersID, özelRol } = require("../../Configs/botConfig");
const moment = require("moment");
require("moment-duration-format");
const db = require("orio.db");

module.exports.run = async (bot, message, args) => {
  if (!developersID.includes(message.author.id)) {
    return;
  }

  let data = db.get("links");

  let button = new MessageButton()
    .setStyle("PRIMARY")
    .setLabel("Uptime Eklemek için Tıkla!")
    .setEmoji("🤖")
    .setCustomId("uptime");

  let button2 = new MessageButton()
    .setStyle("DANGER")
    .setLabel("Uptime Kaldırmak için Tıkla!")
    .setEmoji("🤖")
    .setCustomId("uptime_remove");

  let embed = new MessageEmbed()
    .setAuthor({ name: bot.user.username, iconURL: bot.user.avatarURL() })
    .setDescription(`
Toplam Uptime Sayısı: **${data ? data.length : 0}**
Uptime Süresi: ${moment
        .duration(bot.uptime)
        .format(
          "[**] M [**Month**] W [**Week**] D [**Day**] H [**Hour**] m [**Minute]"
        )}
Ram Kullanımı: **${(process.memoryUsage().heapUsed / 1024 / 2024).toFixed(2) + "mb"}**

> **Verilerin Güncellenme Süresi:** <t:${Math.floor(Date.now() / 1000)}:R>

> **Not:** Sisteme maximum **2 adet** link ekleme hakkı vardır. (<@&${özelRol.rolID}> rolüne sahip kullanıcılar **5 adet** link ekleyebilmektedir.)
> **Not:** Veriler **30 dakikada** bir güncellenmektedir.
   `)
    .setFooter({
      text: `${bot.user.username} Uptime İstatistikleri`,
      iconURL: bot.user.avatarURL(),
    })
    .setThumbnail(bot.user.avatarURL())
    .setColor("BLUE");

  message.channel
    .send({
      embeds: [embed],
      components: [new MessageActionRow({ components: [button, button2] })],
    })
    .then((x) => {
      db.set("message", {
        channelID: message.channel.id,
        messageID: x.id,
      });
    });
};
module.exports.conf = {
  name: "uptime",
  aliases: [],
};
