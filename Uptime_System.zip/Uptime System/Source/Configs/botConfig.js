module.exports = {
  token: "TOKEN",
  prefixs: ["PREFIX"],
  developersID: ["SAHIP ID"],
  playing: "Made by. Expert.", // BOTUN DURUMU

  özelRol: {
   rolID: "ROL ID",
   adet: 5
  }
};
