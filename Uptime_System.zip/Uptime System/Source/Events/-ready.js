const { playing } = require("../Configs/botConfig");
const fetch = require("node-fetch");
const db = require("orio.db");
const bot = global.client;

module.exports = async () => {
  bot.user.setPresence({
    activities: [{ name: playing }],
    status: "idle",
  });

  const data = db.get("links");

 data && data.map((x) => {
    try {
      fetch(x.url);
    } catch (e) {
      console.error(e);
    }
  });

  console.log(`[BOT] ${data ? data.length : 0} tane proje hostlandı.`);

  setInterval(() => {
    const data = db.get("links");

   data && data.map((x) => {
      try {
        fetch(x.url);
      } catch (e) {
        console.error(e);
      }
    });

    console.log(`[BOT] ${db.get("links").length} tane proje hostlandı.`);
  }, 300000);
};
module.exports.conf = {
  name: "ready",
};
