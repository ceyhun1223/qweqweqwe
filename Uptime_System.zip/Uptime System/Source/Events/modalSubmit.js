const { Modal, TextInputComponent, showModal } = require("discord-modals");
const { Formatters } = require("discord.js");
const db = require("orio.db");
const bot = global.client;

module.exports = async (modal) => {
  if (modal.customId === "uptime_message") {
    const firstResponse = modal.getTextInputValue("uptime_url");

    let data = db.get("links");

    await modal.deferReply({ ephemeral: true });
    if (firstResponse.slice(-10) === ".glitch.me" || firstResponse.slice(-11) === ".glitch.me/") {
      if (firstResponse.slice(0, 8) === "https://") {
        if (data && data.map((x) => x.url).includes(firstResponse)) {
          modal.followUp({
            content: `> ❌ **Başarısız!** Eklediğiniz link zaten sistemde bulunuyor. **Linkiniz:** \`${firstResponse}\``,
            ephemeral: true,
          });
          return;
        }
        
        db.push("links", { url: firstResponse, user: modal.user.id });

        modal.followUp({
          content: `> ✅ **Başarılı!** Linkiniz sistemi eklendi! **Link:** \`${firstResponse}\``,
          ephemeral: true,
        });
      } else {
        modal.followUp({
          content: `> ❌ **Başarısız!** Linkinizin başında **https://** bulunması gerekiyor. **Linkiniz:** \`${firstResponse}\`, **Örnek:** \`https://proje-adı.glitch.me\``,
          ephemeral: true,
        });
      }
    } else {
      modal.followUp({
        content: `> ❌ **Başarısız!** Linkinizin sonunda **.glitch.me** bulunması gerekiyor. **Linkiniz:** \`${firstResponse}\`, **Örnek:** \`https://proje-adı.glitch.me\``,
        ephemeral: true,
      });
    }
  }
};
module.exports.conf = {
  name: "modalSubmit",
};
