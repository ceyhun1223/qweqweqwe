const { Modal, TextInputComponent, showModal } = require("discord-modals");
const {
  MessageButton,
  MessageEmbed,
  MessageSelectMenu,
  MessageActionRow,
  Permissions,
} = require("discord.js");
const config = require("../Configs/botConfig");
const db = require("orio.db");
const bot = global.client;

module.exports = async (interaction) => {
  if (!interaction.isSelectMenu()) return;

  let data = db.get("links");
  if (interaction.values[0] === "uptime_allremove") {
    data
      .filter((x) => x.user === interaction.user.id)
      .map((x) => db.unpush("links", { url: x.url }));

    interaction.update({
      content: `> ✅  **Başarılı!** Sistemde bulunan tüm linkler silindi!`,
      components: [],
      ephemeral: true,
    })
    .catch((e) => {});

    return;
  }

  db.unpush("links", { url: interaction.values[0] });

  interaction.update({
    content: `> ✅  **Başarılı!** Seçtiğiniz link sistemden silindi! **Link:** \`${interaction.values[0]}\``,
    components: [],
    ephemeral: true,
  })
   .catch((e) => {});
};
module.exports.conf = {
  name: "interactionCreate",
};
