const { Modal, TextInputComponent, showModal } = require("discord-modals");
const {
  MessageButton,
  MessageEmbed,
  MessageSelectMenu,
  MessageActionRow,
  Permissions,
} = require("discord.js");
const config = require("../Configs/botConfig");
const db = require("orio.db");
const bot = global.client;

module.exports = async (interaction) => {
  if (!interaction.isButton()) return;

  let data = db.get("links");

  if (interaction.customId === "uptime_remove") {
    if (data && data.filter((x) => x.user === interaction.user.id).length <= 0) {
      interaction.reply({
        content: `> ❌ **Başarısız!** Sisteme eklenmiş linkiniz bulunmuyor.`,
        ephemeral: true,
      });

      return;
    }

    let datas = [];
    await data.filter(x => x.user === interaction.user.id).map((x) => {
      datas.push({
        label: x.url,
        value: x.url,
        emoji: { id: "917448428932464700" },
      });
    });

    const otorols = new MessageSelectMenu()
      .addOptions(datas, {
        label: "Hepsini Sil",
        value: "uptime_allremove",
        emoji: { id: "928282667273826355" },
      })
      .setCustomId("uptime_menu")
      .setPlaceholder("Link Seçmek için Buraya Tıkla!")
      .setMaxValues(1)
      .setMinValues(1);

    const buton = new MessageButton()
      .setStyle("SECONDARY")
      .setLabel("İptal")
      .setCustomId("uptime_cancel");

    let group1 = new MessageActionRow().addComponents(otorols);
    let group2 = new MessageActionRow().addComponents(buton);

    interaction.reply({
      content: "**Silmek istediğiniz linki menüden seçin!**",
      components: [group1, group2],
      ephemeral: true,
    });
  }

  if (interaction.customId === "uptime") {
    if (interaction.member.roles.cache.get(config.özelRol.rolID)) {
      if (data && data.filter((x) => x.user === interaction.user.id).length >= config.özelRol.adet) {
        interaction.reply({
          content: `> ❌ **Başarısız!** Özel Roldeki maximum link ekleme sayısına ulaşmışsınız. **Eklediğiniz Link Sayısı:** \`${
            data.filter((x) => x.user === interaction.user.id).length
          }\``,
          ephemeral: true,
        });

        return;
      }
    } else {
      if (data && data.filter((x) => x.user === interaction.user.id).length >= 2) {
        interaction.reply({
          content: `> ❌ **Başarısız!** Maximum link ekleme sayısına ulaşmışsınız. **Eklediğiniz Link Sayısı:** \`${
            data.filter((x) => x.user === interaction.user.id).length
          }\``,
          ephemeral: true,
        });

        return;
      }
    }

    const modal = new Modal()
      .setCustomId("uptime_message")
      .setTitle("Uptime Ekleme Formu!")
      .addComponents(
        new TextInputComponent()
          .setCustomId("uptime_url")
          .setLabel("Glitch Show Link")
          .setStyle("SHORT")
          .setMinLength(20)
          .setMaxLength(100)
          .setPlaceholder("Örnek: https://proje-adı.glitch.me")
          .setRequired(true)
      );

    showModal(modal, {
      client: bot,
      interaction: interaction,
    });
  }
};
module.exports.conf = {
  name: "interactionCreate",
};
